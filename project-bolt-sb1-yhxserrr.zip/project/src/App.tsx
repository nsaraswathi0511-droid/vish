import React from 'react';
import ExpenseTracker from './components/ExpenseTracker';

function App() {
  return (
    <div className="App">
      <ExpenseTracker />
    </div>
  );
}

export default App;